<div class="layout__contact">

  <div class="center center--640">
      <div class="section-help">
        <div class="section-help__heading">
          <h3 class="heading-2">Can't find what you're looking for?</h3>
        </div>
        <div class="section-help__cta">
          <a class="button button--48 button--blue button--inline">Contact us</a>
        </div>
      </div>
    </div>

</div>
