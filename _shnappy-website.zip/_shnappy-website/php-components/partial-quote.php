<div class="layout__quote">

  <div class="section-quote">
    <div class="section-quote__avatar"></div>
    <div class="section-quote__bubble">
      <div class="typography typography--large">
        <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
      </div>
    </div>
    <div class="section-quote__author-name">John Doe</div>
    <div class="section-quote__author-title">Photographer at {{Something}}</div>
  </div>

</div>
