<div class="layout__signup">
  <div class="section-signup">
    <div class="section-signup__heading">
      <div class="section-signup__heading">
        <h2 class="heading-2 text-white text-center">What are you waiting for?</h2>
      </div>
    </div>
    <div class="section-signup__cta">
      <button class="button button--48 button--pink button--inline">
        <!--Create your first Gallery-->
        <!--Start your FREE trial-->
        Get started now!
      </button>
    </div>
    <div class="section-signup__credit">No credit card required, free for 30 days.</div>
  </div>
</div>
