<?php
  include 'pricing-banner.php';
  include 'pricing-content.php';
  include '/php-components/partial-signup.php';
?>
