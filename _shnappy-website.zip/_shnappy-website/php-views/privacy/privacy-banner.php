<!-- banner -->
<div class="layout__banner layout__banner--beta layout__banner--pink">
  <div class="center center--1120">
    <div class="features-banner">
      <div class="features-banner__heading">
        <h1 class="heading-1 text-grey text-center text-white">Privacy</h1>
      </div>
    </div>
  </div>
</div>
