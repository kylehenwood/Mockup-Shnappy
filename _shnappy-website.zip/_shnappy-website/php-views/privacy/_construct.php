<?php
  include 'privacy-banner.php';
  include 'privacy-content.php';
  //include '/php-components/partial-signup.php';
?>
