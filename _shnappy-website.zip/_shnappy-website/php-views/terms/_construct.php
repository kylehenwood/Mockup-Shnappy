<?php
  include 'terms-banner.php';
  include 'terms-content.php';
  //include '/php-components/partial-signup.php';
?>
