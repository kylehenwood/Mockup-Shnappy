<!-- Section -->
<div class="layout__banner layout__banner--gamma layout__banner--pink">
  <div class="center center--1120">

    <div class="help-banner anim--in-bottom">
      <div class="help-banner__headline">
        <h1 class="heading-2 text-white text-center">Help Center</h1>
      </div>
      <div class="help-banner__search">
        <form class="help-search">
          <input class="help-search__input" type="text" placeholder="Search...">
          <div class="help-search__button">
            <button class="button button--36 button--pink">Search</button>
          </div>
        </form>
      </div>
    </div>

  </div>
</div>
