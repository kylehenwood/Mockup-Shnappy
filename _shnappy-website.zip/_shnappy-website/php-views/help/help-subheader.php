<div class="layout__subheader">
  <div class="center center--1120">

    <div class="subheader">
      <div class="subheader__left anim--in-left">
        <a class="subheader-link subheader-link--active" data-pjax="js-pjax-container" activeClass="subheader-link--active">Help center</a>
      </div>
      <div class="subheader__right anim--in-right">
        <a class="subheader-link">Contact support</a>
      </div>
    </div>
  </div>
</div>
